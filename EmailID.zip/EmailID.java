package phase1;
import java.util.ArrayList;
import java.util.*;
public class EmailID {
public static void main(String[] args) {
        
        ArrayList<String> emailID = new ArrayList<String>();
        
        emailID.add("nisha.ytr@gmx.com");
        emailID.add("lila.klein@gmx.com");
        emailID.add("lion.hoch@gmx.com");
        emailID.add("manisha.neumann@gmx.com");
        emailID.add("henry.fiesler@gmx.com");
        emailID.add("laxmi.kramm@gmx.com");
        emailID.add("sabitha.neuwirth@gmx.com");
        
        String EmailID = "nisha.ytr@gmx.com";
        System.out.println("Enter the email to search");
        
        if(emailID.contains(EmailID)){
            System.out.println("EmailID found");
            System.out.println(EmailID);
        }
        else{
            System.out.println( "EmailID not found");
            System.out.println(EmailID);
        }
}
  	}

